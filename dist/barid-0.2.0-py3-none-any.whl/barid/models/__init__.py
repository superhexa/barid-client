from .email import Email
from .details import EmailDetails
from .delete import DeleteResult